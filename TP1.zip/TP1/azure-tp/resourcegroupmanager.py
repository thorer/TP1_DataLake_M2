from azure.identity import AzureCliCredential
from azure.mgmt.resource import ResourceManagementClient

credentiel = AzureCliCredential()
subscription_id = "caaae8aa-a0a7-44db-a52c-2690c23ed8c4"

resource_mgmt_client = ResourceManagementClient(credential, subscription_id)

resource_group_list = resource_mgmt_client.resource_groups.list()
